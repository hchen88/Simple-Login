/**
 * CECS 453 Mobile Application Development
 * Professor Fahim
 * @author: Howard Chen
 * Assignment 1 : Simple Log in
 * Due: July 17, 2019
 * Purpose: This homework assignment is to create a simple log in with a small dictionary
 * as a database for login learning purposes.
 */
package com.howardshowered.assignment1;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.TextureView;
import android.view.View;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {

    private TextView m_txtWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //inflation of acivity_welcome
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        //gets the data from activity_main , Login activity username
        m_txtWelcome = (TextView) findViewById(R.id.txtWelcome);
        Intent intent = getIntent();
        String message = intent.getStringExtra("Message");
        m_txtWelcome.setText(message);//sets the message

    }

}
