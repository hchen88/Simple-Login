/**
 * CECS 453 Mobile Application Development
 * Professor Fahim
 * @author: Howard Chen
 * Assignment 1 : Simple Log in
 * Due: July 17, 2019
 * Purpose: This homework assignment is to create a simple log in with a small dictionary
 * as a database for login learning purposes.
 */
package com.howardshowered.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class SignupActivity extends AppCompatActivity {

    //creates control objects
    private EditText m_txtUsername;
    private EditText m_txtPassword;
    private EditText m_txtRePassword;
    private EditText m_txtEmail;
    private EditText m_txtPhone;
    private Button m_btnSignMeUp = null;


    //this email validation code is borrowed from https://www.tutorialspoint.com/validate-email-address-in-java
    public boolean isValidEmail(String email)
    {
        //regular expression of an email format
        String emailRegex = "^[\\w-\\.+]*[\\w-\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$"; // found on http://regexlib.com

        return email.matches(emailRegex);//returns false/true by matching regex
    }

    //this method matches the phone pattern xxx-xxxxxxx
    //assuming a phone number has only 10 digits
    public boolean isValidPhone(String phone)
    {
        //phone number Regex pattern
        String phoneRegex = "((\\(\\d{3}\\) ?)|(\\d{3}-))?\\d{3}-\\d{4}"; // found on http://regexlib.com

        return phone.matches(phoneRegex); //returns false/true by matching regex
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //assigns all control objects to their correct control fields
        m_txtUsername = (EditText) findViewById(R.id.txtUsername);
        m_txtPassword = (EditText) findViewById(R.id.txtPassword);
        m_txtRePassword = (EditText) findViewById(R.id.txtRetypePassword);
        m_btnSignMeUp = (Button) findViewById(R.id.btnSignMeUp);
        m_txtEmail = (EditText) findViewById(R.id.txtEmail);
        m_txtPhone = (EditText) findViewById(R.id.txtPhone);

        //assigns HashMap data dictionary from getter in main program
        final HashMap<String,String> dataDictionary = LoginActivity.getDataDictionary();

        //gets and sets data from LoginActivity in corresponding fields.
        Intent intent = getIntent();
        m_txtUsername.setText(intent.getStringExtra("Username"));
        m_txtPassword.setText(intent.getStringExtra("Password"));
        m_btnSignMeUp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                // assigns all String variables to their respected string in their control fields
                String password = m_txtPassword.getText().toString();
                String rePassword = m_txtRePassword.getText().toString();
                String username = m_txtUsername.getText().toString();
                String phone = m_txtPhone.getText().toString();
                String email = m_txtEmail.getText().toString();

                //checks conditions of form for errors then sends a Toast
                if (dataDictionary.containsKey(username)) {
                    Toast.makeText(getApplicationContext(), "Username taken!", Toast.LENGTH_LONG).show();
                } else if (username.length() == 0){
                    Toast.makeText(getApplicationContext(), "UserName field is empty!", Toast.LENGTH_LONG).show();
                } else if(password.length() < 8) {
                    Toast.makeText(getApplicationContext(), "Password must be 8 or more characters", Toast.LENGTH_LONG).show();
                }  else if (!password.equals(rePassword)) {
                    Toast.makeText(getApplicationContext(), "Passwords Don't Match!", Toast.LENGTH_LONG).show();
                } else if (password.length() == 0){
                    Toast.makeText(getApplicationContext(), "Password field is empty!", Toast.LENGTH_LONG).show();
                } else if (rePassword.length() == 0){
                    Toast.makeText(getApplicationContext(), "Retype Password field is empty!", Toast.LENGTH_LONG).show();
                }  else if (email.length() == 0){
                    Toast.makeText(getApplicationContext(), "Email field is empty!", Toast.LENGTH_LONG).show();
                } else if (!isValidEmail(email)) {
                    Toast.makeText(getApplicationContext(), "Invalid Email Format! ex: howardchen@gmail.com", Toast.LENGTH_LONG).show();
                } else if (!isValidPhone(phone)){
                    Toast.makeText(getApplicationContext(), "Invalid Phone Format! ex: (123)456-9990", Toast.LENGTH_LONG).show();
                }else if (phone.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Phone field is empty!", Toast.LENGTH_LONG).show();
                } else{ //all conditions met on sign up form, proceeds to add username/password to hashmap with a Sign up success toast!
                    dataDictionary.put(username, password);
                    LoginActivity.setDataDictionary(dataDictionary);
                    Toast.makeText(getApplicationContext(), "You have sucessfully signed up!", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent); //goes back to Login Activity

                }

            }

        });

    }
}
