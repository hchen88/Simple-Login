/**
 * CECS 453 Mobile Application Development
 * Professor Fahim
 * @author: Howard Chen
 * Assignment 1 : Simple Log in
 * Due: July 17, 2019
 * Purpose: This homework assignment is to create a simple log in with a small dictionary
 * as a database for login learning purposes.
 */
package com.howardshowered.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

//class extends generic Android App's class
public class LoginActivity extends AppCompatActivity {

    //control Objects created
    private Button m_btnLogin = null; //Button object for btnLogin
    private Button m_btnSignup = null; //Button object for btnSignup
    private EditText m_txtUsername = null; //EditText object for Username
    private EditText m_txtPassword = null; //EditText object for Password
    private static HashMap<String, String> dataDictionary = new HashMap(); // dictionary database

    /**
     * This is a getter method for the HashMap data dictionary because it is private.
     * @return the dataDictionary in hash map form.
     */
    public static HashMap<String, String> getDataDictionary() {
        return dataDictionary;
    }

    /**
     * This is a setter method for the HashMap data dictionary because it is private.
     */
    public static void setDataDictionary(HashMap<String, String> dataDictionary) {
        LoginActivity.dataDictionary = dataDictionary;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //constructor of the parent class
        setContentView(R.layout.activity_main); //sets the content view to the xml file activity_main

        //assigns control objects with findViewById method
        m_btnLogin = (Button) findViewById(R.id.btnLogin);
        m_btnSignup = (Button) findViewById(R.id.btnSignup);
        m_txtUsername = (EditText) findViewById(R.id.txtUsername);
        m_txtPassword = (EditText) findViewById(R.id.txtPassword);

        //Log in button Listener method
        m_btnLogin.setOnClickListener(new View.OnClickListener() {

            //onClick method : any time the Login button is clicked/tapped this function is called.
            public void onClick(View v) {

                String username = m_txtUsername.getText().toString(); // assigns string of username
                // from plain text field
                String password = m_txtPassword.getText().toString(); // assigns string of password


                if (dataDictionary.containsKey(username)) { // user is in data Dictionary

                    if (dataDictionary.get(username).equals(password)) { //password entered is corrrect

                        Intent intent = new Intent(getApplicationContext(), WelcomeActivity.class);
                        intent.putExtra("Message", "Welcome " + username + "! ");
                        startActivity(intent);

                    } else { // password entered is incorrect
                        //clears password field
                        m_txtPassword.setText("");
                        Toast.makeText(getApplicationContext(), "Incorrect password!", Toast.LENGTH_LONG).show();
                    }
                } else { //Username is not a key in dataDictionary
                    //clears password field
                    m_txtPassword.setText("");
                    //sends Toast for incorrect password/username
                    Toast.makeText(getApplicationContext(), "Incorrect UserName/password!", Toast.LENGTH_LONG).show();
                }

            }
        });

        m_btnSignup.setOnClickListener(new View.OnClickListener() {
            //onClick method : any time the Signup button is clicked/tapped this function is called.
            public void onClick(View v) {

                String username = m_txtUsername.getText().toString(); // gets string of username
                // from plain text field
                String password = m_txtPassword.getText().toString(); // gets string of password  from plain
                // text field

                //sends data to Signup Activity then transitions to SignupActivity.
                Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
                intent.putExtra("Username", username);
                intent.putExtra("Password", password);
                startActivity(intent);

            }

        });
    }
}
